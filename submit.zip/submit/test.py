# import pickle
#
#
# to_read = open('/home/fanfanwu9898/developer/post/ics.pickle', 'rb')
# loc_dict = pickle.load(to_read)
#
# for k, v in loc_dict.items():
#     print(k, v)

from rank import *

bag('ics', 'student', 'affair')
